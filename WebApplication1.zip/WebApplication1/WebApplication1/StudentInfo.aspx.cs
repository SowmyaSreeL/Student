﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication1
{
    public partial class StudentInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString);
                conn.Open();
                string checkuser = "select count(*) from Table where Name='" + N.Text + "'";
                SqlCommand cmd = new SqlCommand(checkuser, conn);
                int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());

                if (temp == 1)
                {
                    Response.Write("Student Already Exist");
                }

                conn.Close();
            }
        }

        protected void Button_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString);
                conn.Open();
                String ins = "insert into Table(Name,Age,Branch,Year,Semister,Prev.percentage) values(@Name,@Age,@Branch,@Year,@Semister,@Prevpercentage)";
                SqlCommand cmd =new SqlCommand(ins, conn);
                cmd.Parameters.AddWithValue("@Name", N.Text);
                cmd.Parameters.AddWithValue("@Age", A.Text);
                cmd.Parameters.AddWithValue("@Branch", B.Text);
                cmd.Parameters.AddWithValue("@Year", Y.Text);
                cmd.Parameters.AddWithValue("@Semister", S.Text);
                cmd.Parameters.AddWithValue("@Prevpercentage", P.Text);
                cmd.ExecuteNonQuery();
                Response.Write("Student registtration successful!");
                N.Text = "";
                A.Text = "";
                B.Text = "";
                Y.Text = "";
                S.Text = "";
                P.Text = "";
                conn.Close();
            }
            catch(Exception exp)
            {
                Console.WriteLine("Unable to insert data!!!");
                Response.Write("Failed!!!"+exp.ToString());
            }
        }
    }
}